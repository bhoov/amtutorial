
```sh
uv sync
export QUARTO_PYTHON=".venv/bin/python"
npm i # Install katex locally
quarto preview index.qmd
```

## Presentation setup code

```sh
quarto create PROJECT
cd PROJECT
uv init .
uv add amtutorial
uv add jupyter ipykernel --dev
uv run ipython kernel install --user --env VIRTUAL_ENV $(pwd)/.venv --name=hamux-presentation
export QUARTO_PYTHON=".venv/bin/python"
quarto preview index.qmd
```