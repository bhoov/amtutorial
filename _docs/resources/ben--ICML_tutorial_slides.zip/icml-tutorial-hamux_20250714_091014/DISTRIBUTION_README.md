# ICML Tutorial Presentation - Distribution Package

## How to View the Presentation

1. **Open the presentation**: Double-click `index.html` or open it in any modern web browser
2. **Navigate**: Use arrow keys or click to navigate through slides
3. **Fullscreen**: Press `F` for fullscreen mode
4. **Overview**: Press `Esc` for slide overview

## Contents

- `index.html` - Main presentation file (open this!)
- `index_files/` - Required JavaScript and CSS libraries
- `node_modules/katex/` - KaTeX math rendering library
- `figs/` - All presentation images
- `videos/` - Video content
- `styles.css` - Custom styling
- `README.md` - Original project README

## Requirements

- Any modern web browser (Chrome, Firefox, Safari, Edge)
- No internet connection required - everything is self-contained
- No additional software needed

## Troubleshooting

If the presentation doesn't load properly:
1. Make sure all files are in the same directory structure
2. Try opening `index.html` directly in your browser
3. Check that your browser allows local file access (some browsers block this for security)
4. Ensure the `node_modules/katex/` folder is present for math rendering

## Math Rendering

This presentation uses KaTeX for mathematical equations. The KaTeX library is included 
locally in `node_modules/katex/` so no internet connection is required.

## Presentation Navigation

- **Next slide**: Space, Arrow Right, Arrow Down
- **Previous slide**: Arrow Left, Arrow Up
- **First slide**: Home
- **Last slide**: End
- **Speaker notes**: Press `S` (if available)
- **Zoom**: `Alt + Click` to zoom in/out

Enjoy the presentation!
